{-- Define a data structure for an expression --}

module Expr (Expression(..), assignment) where

-- data structure to represent a formula (expression)
data Expression = Variable String
                | Top
                | Bottom
                | Universal Expression
                | Existential Expression
                | Conjunction Expression Expression
                | Disjunction Expression Expression
                | Implication Expression Expression
                | Bimplication Expression Expression
                | Negation Expression
                  deriving (Eq, Show, Read)

-- function to assign a value to a variable
assignment :: Expression -> Expression
assignment (Variable s) = Top
